import firebase from "firebase";

firebase.initializeApp({
  apiKey: "",
  authDomain: "",
  databaseURL: "",
  projectId: "",
  storageBucket: "",
  messagingSenderId: "",
  appId: "",
});

const FIREBASE = firebase;

export default FIREBASE;
